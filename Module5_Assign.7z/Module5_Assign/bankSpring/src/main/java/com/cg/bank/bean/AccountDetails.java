package com.cg.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Bank")
public class AccountDetails {
	@Id
	@SequenceGenerator(name = "acc_seq", sequenceName = "acc_seq",initialValue=201900,allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "acc_seq")
	
	private int accountNumber;
	
	private String fName;

	private String aadhaar;
	
	private double amount;
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	
	public String getAadhaar() {
		return aadhaar;
	}
	public void setAadhaar(String password) {
		this.aadhaar = password;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
}
