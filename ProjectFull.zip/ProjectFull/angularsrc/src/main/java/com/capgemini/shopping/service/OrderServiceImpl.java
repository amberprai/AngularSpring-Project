package com.capgemini.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.shopping.bean.Order;
import com.capgemini.shopping.dao.OrderDAO;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderDAO orderDao;
	@Override
	public List<Order> getAllOrders() {
		return orderDao.findAll();
	}
	@Override
	public void createOrder(Order order) {
		Order orderedBook=new Order();
		orderedBook.setOrderId(order.getOrderId());
		orderedBook.setBookTitle(order.getBookTitle());
		orderedBook.setQuantity(order.getQuantity());
		orderedBook.setPrice(order.getPrice());
		float subTotal=order.getPrice()*order.getQuantity();
		orderedBook.setSubTotal(subTotal);
		orderDao.save(orderedBook);
		
	}

}
