import { Component, OnInit } from '@angular/core';
import { Admin } from '../../bean/admin/admin';
import { AdminService } from '../../service/admin/admin.service';
import { ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  admin:Admin={ "id": 0, "email": '', "fullname": '', "password": '' };
  constructor(private adminService:AdminService,private route:ActivatedRoute) { }

  ngOnInit() {
  }

}
