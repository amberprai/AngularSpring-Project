import { Component, OnInit } from '@angular/core';
import { Customer } from '../../../bean/customer/customer';
import { ActivatedRoute, Router } from '../../../../../node_modules/@angular/router';
import { OrderService } from '../../../order.service';
import { Category } from '../../../bean/category/category';
import { CategoryService } from '../../../service/category/category.service';
import { BookService } from '../../../service/book/book.service';
import { Book } from '../../../bean/book/book';


@Component({
  selector: 'app-customerpage',
  templateUrl: './customerpage.component.html',
  styleUrls: ['./customerpage.component.css']
})
export class CustomerpageComponent implements OnInit {
  category:Category={"categoryId":0,"categoryName":''}
  books:Book[];
  categories:Category[];
  customer:Customer={"registeredDate":null,"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"city":'',"zipCode":0,"country":''};
  constructor(private route:ActivatedRoute,private router:Router,private orderService:OrderService,private bookService:BookService,
  private categoryService:CategoryService) { }

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(data=>{this.categories=data});
    this.route.params.subscribe((params)=>{this.orderService.getCustomerById(params['customerId']).subscribe((result)=>{this.customer=result;})});
  }
  search(){
    console.log(this.category.categoryName);
    this.categoryService.getCategoryByName(this.category.categoryName).subscribe(data=>{console.log(data);this.category=data;
      this.bookService.getBookByCategoryId(data.categoryId).subscribe(data1=>{this.books=data1});
    });
    
  }
  categoryBooks(categoryName:string){
    this.bookService.getAllBooks().subscribe(data=>{
    for(let i=0;i<data.length;i++){
        if(data[i].category.categoryName==categoryName){
           // this.books=data[i];
        }
    }
  })}

}
