import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../order.service';
import { Customer } from '../../bean/customer/customer';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-createcustomer',
  templateUrl: './createcustomer.component.html',
  styleUrls: ['./createcustomer.component.css']
})
export class CreatecustomerComponent implements OnInit {
  customerData:Customer={"registeredDate":null,"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"city":'',"zipCode":0,"country":''};
  constructor(private orderService:OrderService,private router:Router) { }

  ngOnInit() {
  }

    create(){
      this.orderService.createCustomer(this.customerData).subscribe(data=>this.router.navigate(['customerlist']));
    }
}
