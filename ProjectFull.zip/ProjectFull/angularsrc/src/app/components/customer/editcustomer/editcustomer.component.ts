import { Component, OnInit } from '@angular/core';
import { OrderService } from '../../../order.service';
import { Router, ActivatedRoute } from '../../../../../node_modules/@angular/router';
import { Customer } from '../../../bean/customer/customer';

@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.css']
})
export class EditcustomerComponent implements OnInit {
  customerData:Customer={"registeredDate":null,"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipCode":0,"city":'',"country":''}
  constructor(private orderService:OrderService,private customerService:OrderService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params) => {this.customerService.getCustomerById(params['customerId']).subscribe((result) => { this.customerData = result; })})
  }
  Register(){
    //console.log(this.customerData);
    this.orderService.register(this.customerData).subscribe(data=>{this.router.navigate(['customerlist'])});

  }
}
