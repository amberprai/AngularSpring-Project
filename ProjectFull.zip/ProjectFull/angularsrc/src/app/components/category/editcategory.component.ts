import { Component, OnInit } from '@angular/core';
import { Category } from '../../bean/category/category';
import { CategoryService } from '../../service/category/category.service';
import { Router, ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-editcategory',
  templateUrl: './editcategory.component.html',
  styleUrls: ['./editcategory.component.css']
})
export class EditcategoryComponent implements OnInit {
  categoryData:Category={"categoryId":0,"categoryName":''}
  constructor(private categoryService:CategoryService,private router:Router, private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params)=>{this.categoryService.getCategory(params['id']).subscribe((result)=>{this.categoryData=result;})});
  }
  updateCategory(){
    console.log(this.categoryData.categoryId);
    this.categoryService.updateCategory(this.categoryData).subscribe((data)=>{this.router.navigate(['category']);});
  }
  cancel(){
    this.router.navigate(['categorylist']);

  }
}
