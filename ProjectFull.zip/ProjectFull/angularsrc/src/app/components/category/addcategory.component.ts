import { Component, OnInit } from '@angular/core';
import { Category } from '../../bean/category/category';
import { CategoryService } from '../../service/category/category.service';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit {
  categoryData:Category={"categoryId":0,"categoryName":''}
  constructor(private categoryService:CategoryService,private router:Router) { }

  ngOnInit() {
  }
  addCategory(){
   
    console.log(this.categoryData.categoryName);
      this.categoryService.addCategory(this.categoryData).subscribe((data)=>{this.router.navigate(['category']);});
      
    }

}
