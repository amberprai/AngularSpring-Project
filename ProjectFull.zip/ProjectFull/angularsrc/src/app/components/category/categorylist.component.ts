import { Component, OnInit } from '@angular/core';
import { Category } from '../../bean/category/category';
import { CategoryService } from '../../service/category/category.service';
import { BookService } from '../../service/book/book.service';
import { Book } from '../../bean/book/book';

@Component({
  selector: 'app-categorylist',
  templateUrl: './categorylist.component.html',
  styleUrls: ['./categorylist.component.css']
})
export class CategorylistComponent implements OnInit {
  categories:Category[];
  books:Book[];
  categoryData:Category={"categoryId":0,"categoryName":''}
    constructor(private categoryService:CategoryService,private bookService:BookService) { }
  
    ngOnInit() {
      //this.categoryService.sortByName(this.categories)
      this.categoryService.getAllCategories().subscribe((data:Category[])=>{this.categories=data});
    }
    deleteCategory(category:Category){
      if(window.confirm("Are you sure you want to delete the category with id "+category.categoryId)){
        this.bookService.getBookByCategoryId(category.categoryId).subscribe(data=>{
          for(let i=0;i<data.length;i++){
            this.bookService.deleteBook(data[i]).subscribe((data)=>{this.books=this.books.filter(c=>c!==data[i])});
          }
        });
        this.categoryService.deleteCategory(category).subscribe((data)=>{this.categories=this.categories.filter(c=>c!==category)});
    }}
    
}
