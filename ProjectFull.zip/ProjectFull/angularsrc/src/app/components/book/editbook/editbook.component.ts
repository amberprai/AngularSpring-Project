import { Component, OnInit } from '@angular/core';
import { Book } from '../../../bean/book/book';
import { BookService } from '../../../service/book/book.service';
import { ActivatedRoute, Router } from '../../../../../node_modules/@angular/router';
import { Review } from '../../../bean/review/review';
import { Category } from '../../../bean/category/category';
import { CategoryService } from 'src/app/service/category/category.service';

@Component({
  selector: 'app-editbook',
  templateUrl: './editbook.component.html',
  styleUrls: ['./editbook.component.css']
})
export class EditbookComponent implements OnInit {
  category:Category={"categoryId":0,"categoryName":''}
  reviews:Review[];
  bookData:Book={"bookId":0,"title":'',"author":'',"isbn":0,"category":this.category,"price":0,"description":'',"publishDate":new Date('yyyy-mmm-dd'),"reviews":this.reviews};
  categories:Array<string>;
  constructor(private bookService: BookService,private categoryService:CategoryService,private router: Router, private route: ActivatedRoute) { }



  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(data=>{this.categories = this.distinct(data)});
    this.route.params.subscribe((params) => {
      this.bookService.getBook(params['bookId'])
      .subscribe((result) => { this.bookData = result })
    })

  }

  edit() {
    console.log(this.bookData.title);
    this.bookService.editBook(this.bookData).subscribe(data=>{this.router.navigate(['/booklist'])});
  }
  distinct(data):Array<string>{
    const categories = new Set();
    const result:Array<string>=[];
    data.map(obj => {if(obj && obj.categoryName)categories.add(obj.categoryName)})
    Array.from(categories).map((cat:string)=>result.push(cat));
    return result;
  }
}
