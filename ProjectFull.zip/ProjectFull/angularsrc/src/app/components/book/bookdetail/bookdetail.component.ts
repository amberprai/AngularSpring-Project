import { Component, OnInit } from '@angular/core';
import { Book } from '../../../bean/book/book';
import { Review } from '../../../bean/review/review';
import { BookService } from '../../../service/book/book.service';
import { ActivatedRoute, Router } from '../../../../../node_modules/@angular/router';
import { Customer } from '../../../bean/customer/customer';
import { OrderService } from '../../../order.service';
import { Orderedbook } from '../../../bean/orderedbook/orderedbook';

@Component({
  selector: 'app-bookdetail',
  templateUrl: './bookdetail.component.html',
  styleUrls: ['./bookdetail.component.css']
})
export class BookdetailComponent implements OnInit {
  review:Review[];
  
  customer:Customer={"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"city":'',"zipCode":0,"registeredDate":null,"country":''};
  reviews:Review={"index":0,"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''};
  bookData:Book={"bookId":0,"title":'',"author":'',"isbn":0,"category":{"categoryId":0,"categoryName":''},"price":0,"description":'',"publishDate":new Date('yyyy-mmm-dd'),"reviews":this.review};
  book:Book={"bookId":0,"title":'',"author":'',"isbn":0,"category":{"categoryId":0,"categoryName":''},"price":0,"description":'',"publishDate":new Date('yyyy-mmm-dd'),"reviews":this.review};
  orderedBook:Orderedbook={"orderedBookId":0,"book":this.book,"quantity":0,"subtotal":0};
  constructor(private router:Router,private bookService:BookService,private route:ActivatedRoute,private orderService:OrderService) { }

  ngOnInit() {
    this.route.params.subscribe((params) => {this.bookService.getBook(params['bookId']).subscribe((result) => { this.book = result; })})
    this.route.params.subscribe((params)=>{this.orderService.getCustomerById(params['customerId']).subscribe((result)=>{this.customer=result;})});
  }
  addtocart(book:Book){
    this.orderedBook.book=book;
    this.orderedBook.quantity=1;
    this.orderedBook.subtotal=1*this.orderedBook.book.price;
    console.log(this.orderedBook);
    this.orderService.createOrderedBook(this.orderedBook).subscribe(data=>{this.router.navigate(['shoppingcart',book.bookId,this.customer.customerId])});
  }
}
