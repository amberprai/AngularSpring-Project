import { Component, OnInit } from '@angular/core';
import { Category } from '../../bean/category/category';
import { CategoryService } from '../../service/category/category.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  categories:Category[];
  constructor(private categoryService:CategoryService) { }

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(data=>{this.categories=data});
  }

}
