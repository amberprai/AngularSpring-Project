import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletereview',
  templateUrl: './deletereview.component.html',
  styleUrls: ['./deletereview.component.css']
})
export class DeletereviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
