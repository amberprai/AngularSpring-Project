import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import { Order } from './order';
import { Router } from '@angular/router';

@Component({
  selector: 'app-createorder',
  templateUrl: './createorder.component.html',
  styleUrls: ['./createorder.component.css']
})
export class CreateorderComponent implements OnInit {
  //order:Order={"orderid":0,"booktitle":'',"author":'',"quantity":0,"price":0,"subtotal":0};
  constructor( private orderService:OrderService, private router:Router) { }

  ngOnInit() {
  }
  //
}
