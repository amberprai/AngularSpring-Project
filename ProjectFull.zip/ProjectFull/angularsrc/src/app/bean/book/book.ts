import { Category } from '../category/category';
import { Review } from '../review/review';

export class Book {
    bookId:number;
    title:string;
    author:string;
    isbn:number;
    category:Category;
    price:number;
    description:string;
    publishDate:Date;
    reviews:Review[];
}

