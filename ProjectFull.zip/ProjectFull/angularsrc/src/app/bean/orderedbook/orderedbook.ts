import { Book } from '../book/book';

export class Orderedbook {
    orderedBookId:number;
    book:Book;
    quantity:number;
    subtotal:number;
}
