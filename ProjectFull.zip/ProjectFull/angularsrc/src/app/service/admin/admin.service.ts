import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Admin } from '../../bean/admin/admin';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  url = 'http://localhost:9090/';
  Admin:Admin;
  constructor(private http: HttpClient) {}
  getAllAdmins() {
    return this.http.get<Admin[]>(this.url+"/getAdmins");
  }
  createAdmin(user: Admin): Observable<Admin[]> {
    return this.http.post<Admin[]>(this.url+"/createAdmin", user);
  }
 
   deleteAdmin(admin:Admin){
    return this.http.delete<Admin[]>(this.url+"/deleteAdmin/"+admin.id);
  }
  login(admin:Admin){
    // this.http.get(this.url+"/getAdminByEmail/"+admin.email).subscribe((data:Admin)=>{
    //   console.log(data);this.Admin=data;});
    //   console.log();
    //   return this.Admin.id;
    return this.http.get<Admin>(this.url+"/getAdminByEmail/"+admin.email);
  }
 

  editAdmin(admin:Admin){
    return this.http.put(this.url+"/editAdmin/"+admin.id,admin);
  }
  getAdmin(id:number){
    console.log(id);
    return this.http.get<Admin>(this.url+"/getAdminById/"+id);
  }
}
