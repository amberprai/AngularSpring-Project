import { Injectable } from '@angular/core';
import { Review } from '../../bean/review/review';
import { HttpClient } from '../../../../node_modules/@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {
  userUrl: string= 'http://localhost:9090/';
  reviewData: Review;
  review:Review[];
  private Id;
  constructor(private http: HttpClient) {}
  public getAllReviews(){
    return this.http.get<Review[]>(this.userUrl+'reviews');
  }
  
  getReview(id:number){
    return this.http.get<Review>(this.userUrl+"reviews/"+id);
  }
  editReview(review:Review){
    return this.http.put(this.userUrl+"reviews/"+review.id,review);
  }

  deleteReview(review:Review){
    console.log(review);
    return this.http.delete<Review[]>(this.userUrl+"reviews/"+review.id);
  }
  addReview(review:Review){
    return this.http.post(this.userUrl+"/addreview",review);
  }
}
