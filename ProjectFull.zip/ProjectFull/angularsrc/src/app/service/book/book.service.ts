import { Injectable } from '@angular/core';
import { Book } from '../../bean/book/book';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private userUrl = 'http://localhost:9090/';
  book: Book;
  //private accountNumber;
  constructor(private http: HttpClient) {}
  getAllBooks() {
    return this.http.get<Book[]>(this.userUrl+"/getAllBooks");
  }


  createBook(book: Book): Observable<Book[]> {
    console.log(book);
    return this.http.post<Book[]>(this.userUrl+"/createBook",book);
  }
 
   deleteBook(book:Book){
     console.log(book.bookId);
    return this.http.delete<Book[]>(this.userUrl+"/deleteBook/"+book.bookId);
  }
  
 

  editBook(book:Book){
    return this.http.put(this.userUrl+"/editBook/"+book.bookId,book);
  }
  getBook(id:number){
    console.log(id);
    return this.http.get<Book>(this.userUrl+"/getBookById/"+id);
  }

  getBookByName(categoryName:string){
    return this.http.get<Book[]>(this.userUrl+"/getBooksByName/"+categoryName);
  }
  getBookByCategoryId(id:number){
    return this.http.get<Book[]>(this.userUrl+"/getBookByCategoryId/"+id);
  }
}
