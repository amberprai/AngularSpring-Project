import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import { Order } from './order';

@Component({
  selector: 'app-updateshoppingcart',
  templateUrl: './updateshoppingcart.component.html',
  styleUrls: ['./updateshoppingcart.component.css']
})
export class UpdateshoppingcartComponent implements OnInit {
  orders:Order[];
  constructor(private orderService:OrderService) { }

  ngOnInit() {
    this.orderService.getOrders().subscribe(data=>{this.orders=data});
  }
  
}
