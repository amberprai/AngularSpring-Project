package com.capgemini.user.service;

import java.util.List;

import com.capgemini.user.dto.Book;
import com.capgemini.user.dto.Category;
import com.capgemini.user.dto.Customer;
import com.capgemini.user.dto.Review;
import com.capgemini.user.dto.User;
import com.capgemini.user.exception.UserException;


public interface UserService {
	List<User> getAllUsers() throws UserException;
	List<User> addUsers(User user) throws UserException;
	List<User> deleteUser(int id) throws UserException;
	List<User> updateUser(int id,User user) throws UserException;
	User getById(int id)  throws UserException;
	User getUserByEmail(String email) throws UserException;
	
	public List<Customer> createCustomer(Customer customer) throws UserException;
    public List<Customer> editCustomer(int id,Customer customer) throws UserException;
    public List<Customer> deleteCustomer(int id) throws UserException;
    public List<Customer> showAllCustomers() throws UserException;
    Customer getCustomerById(int id)throws UserException; 
    
    List<Category> getAllCategories() throws UserException;
    List<Category> addCategory(Category category) throws UserException;
    List<Category> updateCategory(int id,Category category) throws UserException;
    List<Category> deleteCategory(int id) throws UserException;
	Category getByid(int id) throws UserException;
	
	
	List<Review> getAllReviews() throws UserException;
	List<Review> addReview(Review review) throws UserException;
	List<Review> deleteReview(int Id) throws UserException;
	List<Review> editReview(int Id,Review review)throws UserException;
	Review getReviewById(int id) throws UserException;
	
	
	List<Book> getAllBook() throws UserException;
	List<Book> createBook(Book book) throws UserException;
	List<Book> editBook(int id,Book book) throws  UserException;
	List<Book> deleteBook(int id) throws UserException;
	Book getBookById(int id) throws UserException;
	List<Book> getBookByCategoryId(int id) throws  UserException;
}
