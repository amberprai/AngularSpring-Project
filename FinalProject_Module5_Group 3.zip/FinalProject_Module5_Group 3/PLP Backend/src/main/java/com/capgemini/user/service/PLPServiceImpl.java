package com.capgemini.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.user.dao.BookRepo;
import com.capgemini.user.dao.OrderRepo;
import com.capgemini.user.dao.OrdererBookRepo;
import com.capgemini.user.dto.Book;
import com.capgemini.user.dto.Order;

@Service
public class PLPServiceImpl implements PLPService {

	@Autowired
	private OrderRepo orderdao;

	@Autowired
	private OrdererBookRepo orderedBookDao;

	@Autowired
	private BookRepo bookDao;

//	private OrdererBookRepo  

	@Override
	public List<Order> getAllOrders() {
		System.out.println(orderdao.findAll());
		return orderdao.findAll();
	}

	@Override
	public Order getOrderbyId(int id) {

		return orderdao.findById(id).get();
	}

	@Override
	public void delete(int id) {
		orderdao.deleteById(id);
	}

	@Override
	public void edit(int id, Order order) {

		if (orderdao.findById(id) != null) {
			orderdao.save(order);
		}

	}

	@Override
	public Order getOrder(int id) {

		return orderdao.findById(id).get();
	}

	@Override
	public void addBook(String book, Order order) {
		/*
		 * OrderedBook orderedBook = new OrderedBook(); Book book1
		 * =bookDao.getBookbyname(book); Order newOrder=new Order();
		 * orderedBook.setBook(book1);
		 * 
		 * orderdao.save(order); orderedBookDao.save(orderedBook);
		 */
	}

	@Override
	public List<Book> getAllBooks() {
		return bookDao.findAll();
	}

}
