package com.capgemini.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.user.dto.Book;
import com.capgemini.user.dto.Order;
import com.capgemini.user.service.PLPService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class OrderController {

	@Autowired
	private PLPService plpService;

	@GetMapping("/adminOrderList")
	private List<Order> getAllOrders() {
		return plpService.getAllOrders();
	}

	@GetMapping("/getorder/{id}")
	private Order getOrderById(@PathVariable int id) {
		System.out.println(id);
		return plpService.getOrder(id);
	}

	@DeleteMapping("/delete/{id}")
	private void delete(@PathVariable int id) {
		System.out.println(id);
		plpService.delete(id);
	}

	@PutMapping("/edit/{id}")
	private void edit(@PathVariable int id, @RequestBody Order order) {
		plpService.edit(id, order);
	}

	@PostMapping("/addBook/{book}")
	private void addBook(@PathVariable String book, @RequestBody Order order) {
		/* plpService.addBook(book, order); */
	}
	
	@GetMapping("/adminAddBooks")
	private List<Book> getBooks()
	{
		return plpService.getAllBooks();
	}
}
