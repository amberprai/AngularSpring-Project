package com.capgemini.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.user.dao.BookRepo;
import com.capgemini.user.dao.CategoryRepo;
import com.capgemini.user.dao.CustomerRepo;
import com.capgemini.user.dao.ReviewRepo;
import com.capgemini.user.dao.UserRepo;
import com.capgemini.user.dto.Book;
import com.capgemini.user.dto.Category;
import com.capgemini.user.dto.Customer;
import com.capgemini.user.dto.Review;
import com.capgemini.user.dto.User;
import com.capgemini.user.exception.UserException;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepo userDao;
	@Autowired
	private CustomerRepo custdao;
	@Autowired
	private CategoryRepo catgdao;
	@Autowired
	private ReviewRepo reviewDao;
	@Autowired
	private BookRepo bookDao;

	@Override
	public List<User> getAllUsers() throws UserException {

		try {
			return userDao.findAll();
		} catch (Exception e) {

			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<User> addUsers(User user) throws UserException {
		try {
			userDao.save(user);
			return getAllUsers();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<User> deleteUser(int id) throws UserException {

		if (userDao.existsById(id)) {
			userDao.deleteById(id);
			return getAllUsers();
		} else {
			throw new UserException("Cannot delete");
		}

	}

	@Override
	public List<User> updateUser(int id, User user) throws UserException {

		if (userDao.existsById(id)) {
			userDao.save(user);
			return getAllUsers();
		} else {
			throw new UserException("Cannot find ");

		}
	}

	@Override
	public User getById(int id) throws UserException {

		try {
			Optional<User> data = userDao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new UserException("Employee with Id " + id + "does not exist");
			}
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}

	}

	@Override
	public User getUserByEmail(String email) throws UserException {

		return userDao.getUserByEmail(email);
	}

	@Override
	public List<Customer> createCustomer(Customer customer) throws UserException {

		try {

			custdao.save(customer);
			return showAllCustomers();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}

	}

	@Override
	public List<Customer> editCustomer(int id, Customer customer) throws UserException {
		if (custdao.existsById(id)) {
			custdao.save(customer);

			return showAllCustomers();
		} else {
			throw new UserException("Invalid customer cannot be updated");
		}
	}

	@Override
	public List<Customer> deleteCustomer(int id) throws UserException {

		if (custdao.existsById(id)) {
			custdao.deleteById(id);
			return showAllCustomers();
		} else {
			throw new UserException("Cannot delete customer with id " + id + " does not exist");
		}
	}

	@Override
	public List<Customer> showAllCustomers() throws UserException {
		try {
			return custdao.findAll();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public Customer getCustomerById(int id) throws UserException {
		try {
			Optional<Customer> data = custdao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new UserException("Product with id " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new UserException(e.getMessage());

		}
	}

	@Override
	public List<Category> getAllCategories() throws UserException {
		return catgdao.findAll();

	}

	@Override
	public List<Category> addCategory(Category category) throws UserException {
		catgdao.save(category);
		return getAllCategories();
	}

	@Override
	public List<Category> updateCategory(int id, Category category) throws UserException {
		if (catgdao.existsById(id)) {
			catgdao.save(category);
		}
		return getAllCategories();
	}

	@Override
	public List<Category> deleteCategory(int id) throws UserException {
		catgdao.deleteById(id);
		return getAllCategories();
	}

	@Override
	public Category getByid(int id) throws UserException {
		return catgdao.findById(id).get();
	}

	@Override
	public List<Review> getAllReviews() throws UserException {
		return reviewDao.findAll();
	}

	@Override
	public List<Review> addReview(Review review) throws UserException {
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);

		review.setDate(date);
		System.out.println(review);
		reviewDao.save(review);
		return getAllReviews();
	}

	@Override
	public List<Review> deleteReview(int Id) throws UserException {
		reviewDao.deleteById(Id);
		return getAllReviews();
	}

	@Override
	public List<Review> editReview(int Id, Review review) throws UserException {
		if (reviewDao.existsById(review.getId())) {
			Review rev = reviewDao.findById(Id).get();
			rev.setHeadLine(review.getHeadLine());
			rev.setComment(review.getComment());
			reviewDao.save(rev);
			return getAllReviews();
		} else {
			throw new UserException("Invalid Book,Cannot be updated");
		}
	}

	@Override
	public Review getReviewById(int id) throws UserException {
		try {
			Optional<Review> data = reviewDao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new UserException("Review with id " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new UserException(e.getMessage());

		}
	}

	@Override
	public List<Book> getAllBook() throws UserException {

		try {
			return bookDao.findAll();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<Book> createBook(Book book) throws UserException {

		try {
			bookDao.save(book);
			return getAllBook();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<Book> editBook(int id, Book book) throws UserException {
		if (bookDao.existsById(book.getId())) {
			Book books = bookDao.findById(id).get();
			bookDao.save(book);
			return getAllBook();
		} else {
			throw new UserException("Can't be edited");

		}
	}

	@Override
	public List<Book> deleteBook(int id) throws UserException {
		if (bookDao.existsById(id)) {
			bookDao.deleteById(id);
			return getAllBook();
		} else {
			throw new UserException("Can't Delete Book with Id " + id);
		}
	}

	@Override
	public Book getBookById(int id) throws UserException {
		try {
			Optional<Book> data = bookDao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new UserException("Book with id " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}
	@Override
    public List<Book> getBookByCategoryId(int id) throws UserException {
    List<Book> books = getAllBook();
    List<Book> booksbyCat= new ArrayList<>()  ;
    for (Book book : books) {
        if(book.getCategory().getId()==id)
            booksbyCat.add(book);
    }
        return booksbyCat ;
    }

}
