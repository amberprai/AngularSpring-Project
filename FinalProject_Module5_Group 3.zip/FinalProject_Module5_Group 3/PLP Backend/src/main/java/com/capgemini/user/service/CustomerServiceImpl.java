package com.capgemini.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.user.dao.CustomerRepo;
import com.capgemini.user.dto.Customer;
import com.capgemini.user.exception.UserException;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo custDao;

	@Override
	public List<Customer> getAllCustomers() throws UserException {
		return custDao.findAll();
	}

	@Override
	public List<Customer> addCustomer(Customer customer) throws UserException {

		custDao.save(customer);
		return getAllCustomers();
	}

	/*
	 * @Override public List<Customer> deleteCustomer(Customer customer,int id)
	 * throws CustomerException { if (custDao.existsById(id)) {
	 * custDao.deleteById(id); return getAllCustomers(); } else { throw new
	 * CustomerException("customer with id" + id + "does not exist"); } }
	 */

	@Override
	public List<Customer> editCustomer(Customer customer) throws UserException {
		if (custDao.existsById(customer.getId())) {
			custDao.save(customer);
			return getAllCustomers();
		} else {
			throw new UserException("Invalid customer. Cannot update");
		}
	}

	@Override
	public List<Customer> deleteCustomer(int id) throws UserException {
		if (custDao.existsById(id)) {
			custDao.deleteById(id);
			return getAllCustomers();
		} else {
			throw new UserException("customer with id" + id + "does not exist");
		}
	}

	@Override
	public Customer getCustomerById(int id) throws UserException {
		try {
			Optional<Customer> data = custDao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new UserException("Customer with Id " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
	}

	@Override
	public List<Customer> profileCust(Customer customer) throws UserException {
		
		return custDao.findAll();
	}

	@Override
	public List<Customer> registerCustomer(Customer customer) throws UserException {
		custDao.save(customer);
		return getAllCustomers();
		
	}

	@Override
	public Customer login(String email, String password) throws UserException {
	
		Customer customer = custDao.findByEmail(email);
		System.out.println(customer);
		System.out.println(customer.getPassword());
		System.out.println(password);
		if(customer.getPassword().equalsIgnoreCase(password)) {
			return customer;
		}
		else {
			return null;
		}
	
	
	}
}
