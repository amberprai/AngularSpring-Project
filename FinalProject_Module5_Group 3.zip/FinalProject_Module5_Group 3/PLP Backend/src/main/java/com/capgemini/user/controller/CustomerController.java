package com.capgemini.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.capgemini.user.dto.Customer;
import com.capgemini.user.exception.UserException;
import com.capgemini.user.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class CustomerController {

	@Autowired
	private CustomerService custService;

	@PostMapping("/create")
	public List<Customer> addcustomer(@RequestBody Customer customer) throws UserException {

		return custService.addCustomer(customer);

	}

	@GetMapping("/list")
	public List<Customer> getAllCustomers() throws UserException {

		List<Customer> customers = custService.getAllCustomers();

		return customers;
	}

	@GetMapping("/profile")
	public List<Customer> profileCust() throws UserException {

		List<Customer> customers = custService.getAllCustomers();

		return customers;
	}

	@GetMapping("/customerlogin/{email}/{password}")
	public Customer login(@PathVariable String email, @PathVariable String password) throws UserException {
		System.out.println("email "+email+"Pass "+password);
		return custService.login(email, password);
	}

	@DeleteMapping("/{id}")
	public List<Customer> deleteCustomer(@PathVariable int id) throws UserException {
		System.out.println("id = " + id);
		return custService.deleteCustomer(id);
	}

	@PutMapping("/edit")
	public List<Customer> editCustomer(@RequestBody Customer customer) throws UserException {
		return custService.editCustomer(customer);
	}

	@GetMapping("/customer/{id}")
	public Customer getCustomerById(@PathVariable int id) throws UserException {
		return custService.getCustomerById(id);

	}

	@PostMapping("/register")
	public List<Customer> registerCustomer(@RequestBody Customer customer) throws UserException {
		System.out.println(customer);
		return custService.registerCustomer(customer);

	}

}