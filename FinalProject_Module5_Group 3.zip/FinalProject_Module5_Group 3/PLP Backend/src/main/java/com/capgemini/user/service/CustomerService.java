package com.capgemini.user.service;

import java.util.List;

import com.capgemini.user.dto.Customer;
import com.capgemini.user.exception.UserException;


public interface CustomerService {
	
	List<Customer> getAllCustomers() throws UserException;
    List<Customer> addCustomer(Customer customer) throws UserException;
    List<Customer> registerCustomer(Customer customer) throws UserException;
    List<Customer> profileCust(Customer customer) throws UserException;
    List <Customer> deleteCustomer(int id)throws UserException;
	List<Customer> editCustomer(Customer customer) throws UserException;
	Customer getCustomerById(int id) throws UserException;
	Customer login(String email,String password)throws UserException;
    
}
